import requests
import urllib.parse
import re
import telebot

BOT_TOKEN = '8885059462:AAE6VCc9lhA5dGoQhhrFPFGMCvpYcBeqI6U'
bot = telebot.TeleBot(BOT_TOKEN)

def eat_to_access_token(eat_token):
    url = f"https://api-otrss.garena.com/support/callback/?access_token={eat_token}"
    headers = {"User-Agent": "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36"}
    try:
        r = requests.get(url, headers=headers, allow_redirects=True, timeout=15)
        parsed = urllib.parse.urlparse(r.url)
        params = urllib.parse.parse_qs(parsed.query)
        access_token = params.get("access_token", [None])[0]
        account_id = params.get("account_id", ["Unknown"])[0]
        nickname = urllib.parse.unquote(params.get("nickname", ["Unknown"])[0])
        region = params.get("region", ["Unknown"])[0]
        if access_token:
            return {"success": True, "access_token": access_token, "account_id": account_id, "nickname": nickname, "region": region}
        return {"success": False, "error": "access_token nahi mila"}
    except Exception as e:
        return {"success": False, "error": str(e)}

def extract_eat(text):
    text = text.strip()
    if text.startswith("http"):
        parsed = urllib.parse.urlparse(text)
        params = urllib.parse.parse_qs(parsed.query)
        if "eat" in params:
            return params["eat"][0]
    match = re.search(r'eat=([a-f0-9]+)', text)
    if match:
        return match.group(1)
    match = re.search(r'[a-f0-9]{100,}', text)
    if match:
        return match.group(0)
    return None

@bot.message_handler(commands=['start'])
def start(msg):
    bot.reply_to(msg, 
        "👋 **Welcome to Access Token Bot!**\n\n"
        "Main EAT token ko Access Token mein convert karta hoon.\n\n"
        "**Kaise use karein:**\n"
        "• `/token` — EAT token ya URL daalke convert karo\n"
        "• Ya direct EAT token bhejo — auto-detect karega\n\n"
        "**Example:**\n"
        "`/token https://site.com/?eat=abc123...`\n"
        "Ya sirf:\n"
        "`abc123...`",
        parse_mode='Markdown'
    )

@bot.message_handler(commands=['token'])
def token_command(msg):
    text = msg.text.replace('/token', '').strip()
    if not text:
        bot.reply_to(msg, "❌ **Kuch to likho!**\n\nExample:\n`/token https://site.com/?eat=abc123...`\nYa sirf:\n`/token abc123...`", parse_mode='Markdown')
        return
    process_token(msg, text)

@bot.message_handler(func=lambda msg: True)
def handle(msg):
    text = msg.text.strip()
    if text.startswith('/'):
        return
    eat = extract_eat(text)
    if eat:
        process_token(msg, eat)

def process_token(msg, text):
    eat = extract_eat(text)
    if not eat:
        bot.reply_to(msg, "❌ **EAT token nahi mila!** Sahi format mein daalo.", parse_mode='Markdown')
        return
    
    status = bot.reply_to(msg, "⏳ **Converting...**", parse_mode='Markdown')
    result = eat_to_access_token(eat)
    
    if result["success"]:
        bot.edit_message_text(
            f"✅ **EAT → ACCESS TOKEN SUCCESS!**\n\n"
            f"**🔑 Access Token:**\n`{result['access_token']}`\n\n"
            f"**👤 Account Details:**\n"
            f"• **ID:** `{result['account_id']}`\n"
            f"• **Name:** `{result['nickname']}`\n"
            f"• **Region:** `{result['region']}`\n\n"
            f"⏰ Token valid ~8 hours",
            msg.chat.id, status.message_id, parse_mode='Markdown'
        )
    else:
        bot.edit_message_text(
            f"❌ **Conversion Failed!**\n\nError: {result.get('error', 'Unknown')}\n\nToken expire ya invalid ho sakta hai.",
            msg.chat.id, status.message_id, parse_mode='Markdown'
        )

print("✅ Bot is running...")
bot.infinity_polling()
